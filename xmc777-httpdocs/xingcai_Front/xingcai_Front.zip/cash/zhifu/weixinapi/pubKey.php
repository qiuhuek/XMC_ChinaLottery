﻿<?php


$pubKey = '-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCdsspRWTcpCpAllm/rScXz7zNN
Hjjhox/Dpn4cPwY7EYkXmSk4qyGcrh1LLTnaRIKlkFIsQz3uLTrftxrJZmEJwOhA
MAx2PmnZ44rE6l7s/fkd1pfvTvVQVIW1KY/U6e0Uh66wTtrewgvWPpPh7YS1by7J
xsxfS+k5KjdQd1x70QIDAQAB
-----END PUBLIC KEY-----'; 






?>