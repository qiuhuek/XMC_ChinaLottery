<?php

include 'DbConfig.php';

include 'Db.php';

print('ok');