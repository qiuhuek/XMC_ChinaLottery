

<link rel="stylesheet" href="/css/nsc/home/reset.css?v=1.17.1.13">
<link rel="stylesheet" href="/css/nsc/home/theme.css?v=1.17.1.13">
<div class="i_rwzx_box" id="i_rwzx_box" style="display: block;"><span class="close_rwzx_box"></span>
<!--左边-->
<div class="i_rwzx_left">
    <div class="i_rwzx_top">
                    <div class="i_rwzx_top_l bg_percentage33"><p class="tit">新手任务<span>进行中</span></p><p class="percentage"><b>33</b>%</p></div>
        
        <div class="i_rwzx_top_r">
            <h5>完成所有任务，即可豪领 <font class="color_orange">8.0元</font> 新人礼金</h5>
            <p class="bianju showit" style="display:none;">
                <a href="#" class="button_yes" data-value="0">领取 <font class="color_yellow">8.0</font> 元礼金</a>
            </p>
            <p class="bianju showit">
                <a href="#" class="button_yes" data-value="0">领取 <font class="color_yellow">8.0</font> 元礼金</a>
            </p>
            <p class="nowc_rw showit">您还没有完成所有任务,暂时无法领取</p>

            <p class="bianju hideit" style="display:none;">
                <a href="#" class="button_no">您已领取 8.0 元礼金</a>
            </p>
            <p class="yeswc_rw hideit" style="display:none;">继续参与<span class="color_orange">充值福利活动</span>，最高可领80元礼金。
                <a href="/?controller=promotions&amp;action=main" data="T-rmhd" icon="list" title="" class="color_orange">点此参与</a>
            </p>
        </div>
    </div>
    <div class="i_rwzx_list">
        <div class="rwzx_list_item finish">
            <span class="tag"></span>
            <div class="icon icon1"></div>
            <div class="item_r">
                <h4>任务一：绑定银行卡</h4>
                <p>为了方便您的购彩和提款，请先绑定银行卡。</p>
                                    <a href="javascript:void(0);" title="绑定卡号">点此进行绑定</a>
                            </div>
        </div>
        <div class="rwzx_list_item unfinished">
            <span class="tag"></span>
            <div class="icon icon2"></div>
            <div class="item_r">
                <h4>任务二：进行一次成功充值</h4>
                <p>现在充值就可以直接进入你想玩的游戏了~<br>七彩平台有一流的网速银行支付渠道，<br>充值秒速到账，提现三分钟搞定！</p>
                                    <a  href="/index.php/cash/recharge" >点此进行充值</a>
                            </div>
        </div>
        <div class="rwzx_list_item rwzx_list_item3 unfinished">
            <span class="tag"></span>
            <div class="icon icon3"></div>
            <div class="item_r">
                <h4>任务三：进行一次有效投注</h4>
                <p>最火爆的的重庆时时彩和人气超旺的河内1分彩，各类彩种玩法应有尽有，快来试试您的运气吧！</p>
                                    <a target="_top" href="/index.php/index/game/1/2/12/重庆时时彩" icon="">点此进入投注</a>
                            </div>
        </div>
    </div>
</div>
<!--右边-->
<div class="i_rwzx_right">
    <h4 class="tit">其他热门活动</h4>
    <div class="hd_box">
                <div class="hd_item hd_bg1">
                        <div class="hd_item hd_bg1">
                <a href="/?controller=promotions&amp;action=main" title="热门活动" icon="list">
                    <h3>至尊闯关活动</h3>
                    <p>最新活动</p>
                    <span class="ico_go"></span>
                </a>
            </div>
                    </div>
                <div class="hd_item hd_bg1">
                        <div class="hd_item hd_bg2">
                <a href="/?controller=promotions&amp;action=main" title="热门活动" icon="list">
                    <h3>签到有你</h3>
                    <p>火热进行中……</p>
                    <span class="ico_go"></span>
                </a>
            </div>
                    </div>
                <div class="hd_item hd_bg1">
                        <div class="hd_item hd_bg3">
                <a href="/?controller=promotions&amp;action=main" title="热门活动" icon="list">
                    <h3>充值福利</h3>
                    <p>火热进行中……</p>
                    <span class="ico_go"></span>
                </a>
            </div>
                    </div>
            </div>
    <a href="/?controller=promotions&amp;action=main" class="more_activity" data="T-rmhd" icon="list" title="热门活动">更多活动</a>
</div>
</div>
<script type="text/javascript" src="/js/nsc/soundBox.js?v=1.17.1.13"></script>