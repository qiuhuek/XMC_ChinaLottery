﻿<!DOCTYPE html>
<html lang="zh-CN"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><?=$this->settings['webName']?>提醒您：系统正在维护，请稍后访问！</title>
<style type="text/css">
/*==== RESET ====*/
body,div,dl,dt,dd,ul,ol,li,h1,h2,h3,h4,h5,h6,p,pre,code,form,fieldset,legend,blockquote,th,td,figure{margin:0;padding:0;}
li{list-style:none;}

html{-webkit-text-size-adjust:none;-ms-text-size-adjust:none;}
body{font:75%/1.5 Arial,Sans-serif;}
h1,h2,h3,h4,h5,h6{font-size:100%;}

.clearfix{zoom:1;}
.clearfix:after{content:".";display:block;height:0;clear:both;overflow:hidden;visibility:hidden;}

a:link,a:visited{color:#06c;text-decoration:none;}
a:hover,a:active{text-decoration:underline;}

body{background:#F9FAFD;color:#818181;}
.box{width:624px;height:188px;padding:99px 30px 0 184px;background:url(/images/weihu.png) no-repeat 0 0;position:absolute;margin:-144px 0 0 -419px;top:50%;left:50%;font-size:14px;line-height:24px;}
.box .title{margin-bottom:11px;}
.box .text{padding-left:29px;}
</style>
</head>
<body>
<div class="box">
	<div class="title">亲爱的盆友们：</div>
	<div class="text">
		<?=$this->settings['webCloseServiceResult']?>	
	</div>
</div>

</body></html>